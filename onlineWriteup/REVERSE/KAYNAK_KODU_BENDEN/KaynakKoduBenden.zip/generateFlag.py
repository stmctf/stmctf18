with open('flag.txt', 'rb') as f:
    for chunk in iter(lambda: f.read(8), b''):
        line = chunk.encode('hex')
        n=2
        list = [line[i:i+n] for i in range(0, len(line), n)]
        for byte in list:
            res = hex(int(byte, 16) + int("0x01", 16))
            print res[2:].zfill(2)
